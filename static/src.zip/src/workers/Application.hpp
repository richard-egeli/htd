#pragma once
#include <zephyr/kernel.h>

namespace Application {

int Main();
void Continue();
} // namespace Application

